package Paint2D;

/**
 *
 * @author Francisco Beltrán Sánchez
 */
public enum Herramientas {
    Punto, Linea, Cuadrado, Ovalo;
}
